"use client";

import React from "react";
import UserSettingsForm from "@/app/components/UserSettingsForm";

export default function OnboardingPage() {
  return <UserSettingsForm />;
}
