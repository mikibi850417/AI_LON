"use client";

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import { Box, CircularProgress, Typography } from '@mui/material';

export default function AuthCallback() {
  const router = useRouter();

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        const { data, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('Auth callback error:', error);
          router.push('/auth/login?error=auth_failed');
          return;
        }

        if (data.session?.user) {
          // 구글 로그인 성공 시 users 테이블에 사용자 정보 확인/생성
          const { data: existingUser, error: userError } = await supabase
            .from('users')
            .select('*')
            .eq('id', data.session.user.id)
            .maybeSingle();

          if (userError && userError.code !== 'PGRST116') {
            console.error('User lookup error:', userError);
          }

          // 사용자가 존재하지 않으면 생성
          if (!existingUser) {
            const { error: insertError } = await supabase
              .from('users')
              .insert([
                {
                  id: data.session.user.id,
                  email: data.session.user.email,
                  is_initialized: false
                }
              ]);

            if (insertError) {
              console.error('User creation error:', insertError);
            }
          }

          // 로그인 페이지로 리다이렉트 (로그인된 상태로 표시됨)
          router.push('/auth/login');
        } else {
          router.push('/auth/login?error=no_session');
        }
      } catch (err) {
        console.error('Auth callback process error:', err);
        router.push('/auth/login?error=callback_failed');
      }
    };

    handleAuthCallback();
  }, [router]);

  return (
    <Box sx={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '100vh',
      gap: 2
    }}>
      <CircularProgress size={40} />
      <Typography variant="body1" color="text.secondary">
        로그인 처리 중...
      </Typography>
    </Box>
  );
} 